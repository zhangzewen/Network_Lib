/*
 *****************************************************************
 *                   C++ Logger Toolkit Library                  *
 *                                                               *
 * C++ Logger Toolkit Library Example                            *
 * Author: Arash Partow (2005)                                   *
 * URL: http://www.partow.net/programming/logtk/index.html       *
 *                                                               *
 * Copyright notice:                                             *
 * Free use of the Logger Toolkit Library is permitted under the *
 * guidelines and in accordance with the most current version of *
 * the Common Public License.                                    *
 * http://www.opensource.org/licenses/cpl1.0.php                 *
 *                                                               *
 *****************************************************************
*/


#include <iostream>
#include <string>
#include <cmath>

#include "logtk.hpp"

int main()
{
   const std::string log_name = "logtk_example";
   const std::string path     = ".";

   if (!logtk::start_logger(log_name,path))
   {
      std::cerr << "ERROR - Failed to start logger!\n";
      return 1;
   }

   logtk::log("Starting p^2 loop.");

   const double pi2 = (3.14159265358979323846 * 3.14159265358979323846);

   for (std::size_t i = 0; i < 1000; ++i)
   {
      double pi_4 = 0.0;
      for (std::size_t j = 0; j < i; ++j)
      {
         pi_4 += 1.0 / ((j + 1.0) * (j + 1.0));
      }

      logtk::log("log[%03d] pi^2 = %20.18f\terror = %20.18f",
                 i,
                 6.0 * pi_4,
                 std::abs((6.0 * pi_4) - pi2));
   }

   logtk::log("Completed p^2 loop.");

   if (!logtk::stop_logger())
   {
      std::cerr << "ERROR - Failed to stop logger!\n";
      return 1;
   }

   return 0;
}
