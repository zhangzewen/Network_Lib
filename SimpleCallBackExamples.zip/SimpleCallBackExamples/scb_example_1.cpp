/*
  **********************************************************************
  *                                                                    *
  *           Simple Call-Back Examples (version 0.0.1)                *
  *                                                                    *
  * Source Code: Example 1                                             *
  * Author: Arash Partow - 2000                                        *
  * URL: http://www.partow.net/programming/templatecallback/index.html *
  *                                                                    *
  * Copyright Notice:                                                  *
  * Free use of this library is permitted under the guidelines and     *
  * in accordance with the most current version of the Common Public   *
  * License.                                                           *
  * http://opensource.org/licenses/cpl1.0                              *
  *                                                                    *
  **********************************************************************
*/


#include <iostream>

class AClass
{
public:

   void method1(unsigned int value)
   {
      std::cout << "Method 1 - Value: " << value << std::endl;
   }

   bool method2(unsigned int value)
   {
      std::cout << "Method 2 - Value: " << value << std::endl;
      return true;
   }
};

int main()
{
   AClass instance;

   {
      void (AClass::*MethodType1)(unsigned int);

      MethodType1 = &AClass::method1;

      (instance.*MethodType1)(123);
   }

   {
      bool (AClass::*MethodType2)(unsigned int);

      MethodType2 = &AClass::method2;

      if ((instance.*MethodType2)(456))
        std::cout << "Method returned a TRUE result." << std::endl;
      else
        std::cout << "Method returned a FALSE result." << std::endl;
   }

   return 0;
}
