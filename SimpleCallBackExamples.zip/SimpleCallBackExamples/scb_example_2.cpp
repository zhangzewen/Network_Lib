/*
  **********************************************************************
  *                                                                    *
  *           Simple Call-Back Examples (version 0.0.1)                *
  *                                                                    *
  * Source Code: Example 2                                             *
  * Author: Arash Partow - 2000                                        *
  * URL: http://www.partow.net/programming/templatecallback/index.html *
  *                                                                    *
  * Copyright Notice:                                                  *
  * Free use of this library is permitted under the guidelines and     *
  * in accordance with the most current version of the Common Public   *
  * License.                                                           *
  * http://opensource.org/licenses/cpl1.0                              *
  *                                                                    *
  **********************************************************************
*/


#include <iostream>

template <typename AType>
class AClass
{
public:

   AClass(AType data)
   : data_(data)
   {}

   AType operator()()
   {
      std::cout << data_ << std::endl;
      return data_;
   }

private:

   AType data_;
};


int main()
{
   {
      int (AClass<int>::*int_method)();

      AClass <int> instance1(123);

      int_method = &AClass<int>::operator();

      (instance1.*int_method)();
   }

   {
      double (AClass<double>::*double_method)();

      AClass<double> instance2(456.789);

      double_method = &AClass<double>::operator();

      (instance2.*double_method)();
   }

   return 0;
}
