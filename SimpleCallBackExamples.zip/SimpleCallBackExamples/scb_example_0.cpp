/*
  **********************************************************************
  *                                                                    *
  *           Simple Call-Back Examples (version 0.0.1)                *
  *                                                                    *
  * Source Code: Example 0                                             *
  * Author: Arash Partow - 2000                                        *
  * URL: http://www.partow.net/programming/templatecallback/index.html *
  *                                                                    *
  * Copyright Notice:                                                  *
  * Free use of this library is permitted under the guidelines and     *
  * in accordance with the most current version of the Common Public   *
  * License.                                                           *
  * http://opensource.org/licenses/cpl1.0                              *
  *                                                                    *
  **********************************************************************
*/


#include <iostream>

class AClass
{
public:

   void method1()
   {
      std::cout << "Method 1" << std::endl;
   }

   void method2()
   {
      std::cout << "Method 2" << std::endl;
   }
};


int main()
{
   void (AClass::*Method)(void);

   {
      AClass  inst1;
      Method = &AClass::method1;
      (inst1.*Method)();
   }

   {
      AClass* inst2 = new AClass;
      Method = &AClass::method2;
      (inst2->*Method)();
      delete inst2;
   }

   return 0;
}
